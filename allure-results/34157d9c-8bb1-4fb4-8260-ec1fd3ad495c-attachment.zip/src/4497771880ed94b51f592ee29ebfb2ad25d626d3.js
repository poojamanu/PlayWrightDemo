import {test} from "@playwright/test"
test('screenshot',async({page})=>{
    await page.goto("https://www.saucedemo.com/")
    await page.screenshot({path:'screenshot/screenshot.png',fullPage:true})
})