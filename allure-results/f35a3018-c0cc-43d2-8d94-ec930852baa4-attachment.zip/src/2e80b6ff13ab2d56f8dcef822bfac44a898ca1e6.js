import { test, expect } from "@playwright/test"
//https://restful-booker.herokuapp.com/apidoc/index.html?utm_source=chatgpt.com#api-Booking-CreateBooking
test('post_api', async ({ request }) => {
    const authData =
    {
        "username": "admin",
        "password": "password123"
    }

    const response = await request.post("https://restful-booker.herokuapp.com/auth", { headers: { 'Content-Type': 'application/json' }, data: authData })
    console.log(response.status())
    const responseJson = await response.json()
    console.log(responseJson)
    expect(responseJson.token).not.toBeNull() //to assert token should not be null
})


//to create booking

test("create_booking", async ({ request }) => {
    const bookingData =
    {
        "firstname": "Jim",
        "lastname": "Brown",
        "totalprice": 111,
        "depositpaid": true,
        "bookingdates": {
            "checkin": "2018-01-01",
            "checkout": "2019-01-01"
        },
        "additionalneeds": "Breakfast"
    }

    const response = await request.post("https://restful-booker.herokuapp.com/booking", { headers: { 'Content-Type': 'application/json' }, data: bookingData })
    console.log(response.status())
    const responseJson = await response.json()
    console.log(responseJson)
    expect(responseJson.bookingid).not.toBeNull()
    console.log("booking id is:" + responseJson.bookingid)
    expect(responseJson.booking.firstname).toBe(bookingData.firstname)
})

// to update a booking
test("update_booking", async ({ request }) => {
    // genarate token
    const authData =
    {
        "username": "admin",
        "password": "password123"
    }
    const authResponse = await request.post("https://restful-booker.herokuapp.com/auth", { data: authData, headers: { 'Content-Type': 'application/json' } })
    const authJson = await authResponse.json()
    const token = authJson.token
    expect(token).toBeTruthy();
    //create booking
    const bookingData =
    {
        "firstname": "James updated",
        "lastname": "Brown",
        "totalprice": 111,
        "depositpaid": true,
        "bookingdates": {
            "checkin": "2018-01-02",
            "checkout": "2019-01-03"
        },
        "additionalneeds": "Breakfast"
    }
    const bookingResponse = await request.post("https://restful-booker.herokuapp.com/booking", { headers: { 'Content-Type': 'application/json' }, data: bookingData })
    expect(bookingResponse.status).toBe("200")
    const bookingJson = await bookingResponse.json()
    const bookingId = bookingJson.bookingid

    //update booking

    const updateBooking = {
        firstname: "James",
        lastname: "Brown",
        totalprice: 111,
        depositpaid: true,
        bookingdates: {
            checkin: "2018-01-02",
            checkout: "2019-01-013"
        },
        additionalneeds: "Breakfast"
    }
    const updateResponse = await request.put(`https://restful-booker.herokuapp.com/booking/${bookingId}`,
        {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Cookie': `token=${token}'`
            },
            data: updateBooking
        })
    const updatedResponse = await updatedResponse.json()
    expect(updatedResponse.status()).toBe("200")
    const updateJson=await updatedResponse.json()
    expect(updateJson.firstname).toBe("James")
    expect(updateJson.bookingdates.checkout).toBe("2019-01-013")

})