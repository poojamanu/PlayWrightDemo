import { test } from "@playwright/test"

test('post_api', async ({ request }) => {
    const authData =
    {
        "username": "admin",
        "password": "password123"
    }

    const response = await request.post("https://restful-booker.herokuapp.com/auth",{headers:{'Content-Type': 'application/json'},data:authData})
    console.log(response.status())
const responseJson=await response.json()
    console.log(responseJson)
expect(responseJson.token).not.toBeNull() //to assert token should not be null
})